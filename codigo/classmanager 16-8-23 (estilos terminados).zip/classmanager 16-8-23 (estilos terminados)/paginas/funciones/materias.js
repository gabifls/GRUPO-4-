// DECLARACION DE VARIABLES

materia = document.getElementsById("caja");
materia.onclick = Agregar();
titulo = document.getElementById("titulo");
titulo2 = document.getElementById("titulo2");
titulo3 = document.getElementById("titulo3");
titulo4 = document.getElementById("titulo4");
titulo5 = document.getElementById("titulo5");
titulo6 = document.getElementById("titulo6");

// FUNCIONES PARA PAGINA CURSOS

function Agregar() {
    let nombre_materia = prompt("Cúal es la materia que querés agregar?");
    titulo.innerHTML = nombre_materia;
}
function Agregar2() {
    let nombre_materia2 = prompt("Cúal es la materia que querés agregar?");
    titulo2.innerHTML = nombre_materia2;
}
function Agregar3() {
    let nombre_materia3 = prompt("Cúal es la materia que querés agregar?");
    titulo3.innerHTML = nombre_materia3;  
}
function Agregar4() {
    let nombre_materia4 = prompt("Cúal es la materia que querés agregar?");
    titulo4.innerHTML = nombre_materia4;
}
function Agregar5() {
    let nombre_materia5 = prompt("Cúal es la materia que querés agregar?");
    titulo5.innerHTML = nombre_materia5;
}
function Agregar6() {
    let nombre_materia6 = prompt("Cuál es la materia que querés agregar?");
    titulo5.innerHTML = nombre_materia6;
}
