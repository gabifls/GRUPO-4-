// DECLARACION DE VARIABLES

curso = document.getElementsById("caja");
curso.onclick = Agregar();
titulo = document.getElementById("titulo");
titulo2 = document.getElementById("titulo2");
titulo3 = document.getElementById("titulo3");
titulo4 = document.getElementById("titulo4");
titulo5 = document.getElementById("titulo5");
titulo6 = document.getElementById("titulo6");

// FUNCIONES PARA PAGINA CURSOS

function Agregar() {
    let nombre_curso = prompt("Cúal es el curso que querés agregar?");
    titulo.innerHTML = nombre_curso;
}
function Agregar2() {
    let nombre_curso2 = prompt("Cúal es el curso que querés agregar?");
    titulo2.innerHTML = nombre_curso2;
}
function Agregar3() {
    let nombre_curso3 = prompt("Cúal es el curso que querés agregar?");
    titulo3.innerHTML = nombre_curso3;  
}
function Agregar4() {
    let nombre_curso4 = prompt("Cúal es el curso que querés agregar?");
    titulo4.innerHTML = nombre_curso4;
}
function Agregar5() {
    let nombre_curso5 = prompt("Cúal es el curso que querés agregar?");
    titulo5.innerHTML = nombre_curso5;
}
function Agregar6() {
    let nombre_curso6 = prompt("Cuál es el curso que querés agregar?");
    titulo5.innerHTML = nombre_curso6;
}
