// DECLARACION DE VARIABLES

escuela = document.getElementsById("caja");
escuela.onclick = Agregar();
titulo = document.getElementById("titulo");
titulo2 = document.getElementById("titulo2");
titulo3 = document.getElementById("titulo3");
titulo4 = document.getElementById("titulo4");
titulo5 = document.getElementById("titulo5");
titulo6 = document.getElementById("titulo6");

// FUNCIONES PARA PAGINA ESCUELAS

function Agregar() {
    let nombre_escuela = prompt("Cúal es la escuela que querés agregar?");
    titulo.innerHTML = nombre_escuela;
}
function Agregar2() {
    let nombre_escuela2 = prompt("Cúal es la escuela que querés agregar?");
    titulo2.innerHTML = nombre_escuela2;
}
function Agregar3() {
    let nombre_escuela3 = prompt("Cúal es la escuela que querés agregar?");
    titulo3.innerHTML = nombre_escuela3;  
}
function Agregar4() {
    let nombre_escuela4 = prompt("Cúal es la escuela que querés agregar?");
    titulo4.innerHTML = nombre_escuela4;
}
function Agregar5() {
    let nombre_escuela5 = prompt("Cúal es la escuela que querés agregar?");
    titulo5.innerHTML = nombre_escuela5;
}
function Agregar6() {
    let nombre_escuela6 = prompt("Cuál es la escuela que querés agregar?");
    titulo5.innerHTML = nombre_escuela6;
}
