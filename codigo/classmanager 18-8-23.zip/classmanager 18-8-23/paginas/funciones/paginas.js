escuela = document.getElementsById("caja");
escuela.onclick = Agregar();
titulo = document.getElementById("titulo");
titulo2 = document.getElementById("titulo2");
titulo3 = document.getElementById("titulo3");
titulo4 = document.getElementById("titulo4");

function Agregar() {
    let nombre_escuela = prompt("Cúal es la escuela que queres agregar?");
    titulo.innerHTML = nombre_escuela;
}
function Agregar2() {
    let nombre_escuela2 = prompt("Cúal es la escuela que queres agregar?");
    titulo2.innerHTML = nombre_escuela2;
}
function Agregar3() {
    let nombre_escuela3 = prompt("Cúal es la escuela que queres agregar?");
    titulo3.innerHTML = nombre_escuela3;  
}
function Agregar4() {
    let nombre_escuela4 = prompt("Cúal es la escuela que queres agregar?");
    titulo4.innerHTML = nombre_escuela4;
}