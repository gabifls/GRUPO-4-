<?php
    $usr= $_POST["usr"]
    $psw= $_POST["psw"]

    $enlace= mysqli_connect(localhost,$usr,$psw,$nombreBADA);


    $consulta="SELECT * FROM Login";
    $query="insert into
            login(nombre_apellido, password)
            values($usr, $psw)
    
    $resultado= mysqli_query($enlace, $consulta)
?>



