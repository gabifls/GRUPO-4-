<?php
    $usr= $_POST["usuario"]
    $psw= $_POST["new_psw"]
    $rep_psw= $_POST["rep_psw"]

    $enlace= mysqli_connect(localhost,$usr,$psw,$rep_psw,$nombreBADA);


    $consulta="SELECT * FROM Restablecer_psw";
    $query="insert into
            login(usuario, contraseña, rep_contraseña)
            values($usr, $psw, $rep_psw)
    
    $resultado= mysqli_query($enlace, $consulta)
?>
