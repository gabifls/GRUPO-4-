<?php
    $usuario= $_POST["usuario"]
    $contra= $_POST["contra"]
    $rep_contra= $_POST["rep_contra"]

    $enlace= mysqli_connect(localhost,$usuario,$contra, $rep_contra,$nombreBADA);


    $consulta="SELECT * FROM registro";
    $query="insert into
            registro(usuario, contraseña, rep_contraseña)
            values($usuario, $contra, $rep_contra)
    
    $resultado= mysqli_query($enlace, $consulta)
?>
 
