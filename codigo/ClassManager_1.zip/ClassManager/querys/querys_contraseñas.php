<?php
    $enlace= mysqli_connect(localhost,root,grupo4-Mclass,classmanagerdb);
    
    $servername ="classmanagerfa";
    $usr= $_POST["root"];
    $psw= $_POST["grupo4-Mclass"];
    $rep_psw= $_POST["rep_psw"];

    

    if($enlace->connect_error)  {
        die("conexion fallida: " . $enlace->connect_error);
    }
     else {
        $consulta="SELECT * FROM Restablecer_psw";

        $query="insert into
            login(usuario, contraseña, rep_contraseña)
            values($usr, $psw, $rep_psw)"
          $resultado= mysqli_query($enlace, $consulta)
     }
   if ($enlace->query($resultado) === TRUE) {
        echo "Contraseña reestablecida"; 
    }
    else {
        echo "N/o se ha podido restablecer la contraseña" .$elace->error;
    }

    $enlace->close();

     }

    

?>
