<?php
    $usr= $_POST["usr"]
    $psw= $_POST["psw"]

    $enlace= mysqli_connect(localhost,root,grupo4-Mclass,classmanagerdb);

    $usuario= "SELECT nombre_apellido FROM login";
    $contraseña= "SELECT contraseña FROM login";
    
    if($usr === $usuario and $psw === $contraseña){
        echo("Ingresaste")
    } else {
        echo("no se encontro el usurio o la contraseña es incorrecta")
    }


